# Craft Room / Applied Fabrication Lab – Background
(See prior version; retained verbatim for continuity.)
